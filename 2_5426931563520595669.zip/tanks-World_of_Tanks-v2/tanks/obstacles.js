const obstacles = [
    {
        x: 1,
        y: 1,
        block: 1
    },
    {
        x: 1,
        y: 0,
        block: 2
    },
    {
        x: 0,
        y: 3,
        block: 1
    },
    {
        x: 0,
        y: 4,
        block: 3
    },
    {
        x: 2,
        y: 3,
        block: 2

    },
    {
        x: 2,
        y: 2,
        block: 3
    },
    {
        x: 2,
        y: 5,
        block: 1
    },
    {
        x: 1,
        y: 6,
        block: 5
    },
    {
        x: 1,
        y: 7,
        block: 5
    },
    {
        x: 2,
        y: 1,
        block: 3
    },
    {
        x: 1,
        y: 8,
        block: 5
    },
    {
        x: 2,
        y: 6,
        block: 1
    },
    {
        x: 3,
        y: 9,
        block: 1
    },
    {
        x: 3,
        y: 8,
        block: 1
    },
    {
        x: 2,
        y: 0,
        block: 5
    },
    {
        x: 4,
        y: 5,
        block: 3
    },
    {
        x: 4,
        y: 6,
        block: 2
    },
    {
        x: 4,
        y: 8,
        block: 4
    },
    {
        x: 4,
        y: 3,
        block: 5
    },
    {
        x: 4,
        y: 2,
        block: 4
    },
    {
        x: 4,
        y: 1,
        block: 3
    },
    {
        x: 5,
        y: 2,
        block: 2
    },
    {
        x: 5,
        y: 6,
        block: 2
    },
    {
        x: 6,
        y: 1,
        block: 1
    },
    {
        x: 6,
        y: 2,
        block: 3
    },
    {
        x: 6,
        y: 3,
        block: 3
    },
    {
        x: 6,
        y: 4,
        block: 3
    },
    {
        x: 6,
        y: 3,
        block: 1
    },
    {
        x: 6,
        y: 8,
        block: 3
    },
    {
        x: 6,
        y: 9,
        block: 3
    },
    {
        x: 7,
        y: 2,
        block: 2
    },
    {
        x: 7,
        y: 6,
        block: 2
    },
    {
        x: 7,
        y: 9,
        block: 4
    },
    {
        x: 8,
        y: 4,
        block: 5
    },
    {
        x: 8,
        y: 6,
        block: 2
    },
    {
        x: 8,
        y: 7,
        block: 2
    },
    {
        x: 9,
        y: 2,
        block: 3
    },
]
